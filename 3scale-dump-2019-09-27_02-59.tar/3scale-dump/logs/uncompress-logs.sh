#!/bin/bash

for FILE in *.xz; do
	xz -d ${FILE}

done
